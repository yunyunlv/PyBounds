Implementing partial identification estimators. This is a Python version of a very old Stata and Matlab packages that Arie wrote with Chuck Manski when he was a grad student. This package is under development and is in its infancy. Comments, suggestions and help are, obviously welcome.

Team: Arie Beresteanu, Yunyun Lv

Plan:

-stage 1: Implement all that we had in the Stata/Matlab package
-stage 2: Implement Beresteanu & Molinary 2012
-stage 3: Implement Beresteanu Sasaki 2020
-stage 4: Implement other papers out there